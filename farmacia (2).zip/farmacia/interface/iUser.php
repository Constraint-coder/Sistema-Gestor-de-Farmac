<?php 

interface iUser{
	public function user_login($username, $password);
}//end iUser
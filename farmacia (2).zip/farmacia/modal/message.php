<div class="modal fade" id="modal-message">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Caja de mensajes</h4>
			</div>
			<div class="modal-body">
				<h4 id="msg-body">Todo bien</h4>
			</div>
			<div class="modal-footer">
				<button type="button" id="message-box-ok" class="btn btn-default" data-dismiss="modal">OK
				<span class="glyphicon glyphicon-ok" aria-hidden="true"></span>
				</button>
			</div>
		</div>
	</div>
</div>
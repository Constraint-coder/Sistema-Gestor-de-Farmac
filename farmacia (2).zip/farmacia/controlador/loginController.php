<?php
session_start();
$user = $_POST['user'];
$pass = $_POST['pass'];
echo $user;
echo " ";
echo $pass;
?>
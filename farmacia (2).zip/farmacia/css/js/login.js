const inputs = document.querySelectorAll(".input");


function addcl(){
    let parant = this.parentNode.parentNode;
    parent.classList.add("focus");
}

function remcl(){
    let parent = this.parentNode.parentNode;
    if(this.value == ""){
        parent.classList.remove("focus");
    }
}

inputs.forEach(inpput => {
    inputs.addEventListener("focus", addcl);
    inputs.addEventListener("blur", remcl);
})